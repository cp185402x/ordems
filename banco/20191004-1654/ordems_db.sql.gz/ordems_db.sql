-- MariaDB dump 10.17  Distrib 10.4.6-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ordems_db
-- ------------------------------------------------------
-- Server version	10.4.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ordems_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ordems_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ordems_db`;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `data_nasc` date DEFAULT NULL,
  `data_uedit` date DEFAULT NULL,
  `nm_cliente` varchar(60) DEFAULT NULL,
  `tipo_cliente` int(1) DEFAULT 1,
  `doc_num` varchar(15) DEFAULT NULL,
  `rg_ie` varchar(15) DEFAULT NULL,
  `celular` varchar(15) DEFAULT NULL,
  `fone_re` varchar(15) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `pes_contato` varchar(20) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `numero` varchar(6) DEFAULT NULL,
  `complemento` varchar(40) DEFAULT NULL,
  `bairro` varchar(40) DEFAULT NULL,
  `cidade` varchar(40) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `doc_num_UNIQUE` (`doc_num`),
  KEY `fk_clientes_as_usuario` (`usuario_id`),
  CONSTRAINT `fk_clientes_as_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,1006,'2019-09-13 00:46:48','1979-09-12','2019-09-12','EDILSON BARROS',1,'83250924572','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(2,1007,'2019-09-13 00:46:48','1979-09-12','2019-09-12','CARLOS CRISTIANO',1,'83250924574','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1080','NOVA CAMPINAS','CAMPINAS','SP'),(3,1008,'2019-09-13 00:46:48','1979-09-12','2019-09-12','VINICIUS LAZARINI',1,'83240924575','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1081','NOVA CAMPINAS','CAMPINAS','SP'),(4,1007,'2019-09-25 00:46:48','1979-09-12','2019-09-12','EDILSON R BARROS',1,'83250924573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(5,1007,'2019-09-25 00:46:48','1979-09-12','2019-09-12','EDILSON R BARROS',1,'83250927573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(6,1007,'2019-09-25 00:46:48','1979-09-12','2019-09-12','EDILSON R BARROS',1,'83850927573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(8,1007,'2019-09-25 00:46:48','1979-09-12','2019-09-12','EDILSON R BARROS',1,'83890927573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(9,1008,'2019-09-30 22:43:14','1979-09-12','2019-09-12','VINICIUS LAZARINI',1,'83897927573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(14,1008,'2019-10-02 00:59:30','1979-09-12','2019-09-12','VINICIUS LAZA',1,'83897956573','39112563','19988020800','1932540100','edilson.barros@aluno.ifsp.edu.br','O MESMO','13010000','AV. DR. MORAES SALES','1000','APTO-1079','NOVA CAMPINAS','CAMPINAS','SP'),(17,1006,'2019-10-04 02:31:50',NULL,NULL,'EDILSON RODRIGUES',0,'83250678725','265896587',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,1006,'2019-10-04 02:33:53',NULL,NULL,'VINICIUS LAZARINE',0,'83250678728','265896587',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estoque_peca`
--

DROP TABLE IF EXISTS `estoque_peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estoque_peca` (
  `id_peca` int(11) NOT NULL,
  `estoque_atual` int(11) NOT NULL,
  `estoque_minimo` int(11) NOT NULL,
  `estoque_maximo` int(11) NOT NULL,
  KEY `Index 1` (`id_peca`),
  CONSTRAINT `fk_peca_estoque` FOREIGN KEY (`id_peca`) REFERENCES `peca` (`id_peca`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estoque_peca`
--

LOCK TABLES `estoque_peca` WRITE;
/*!40000 ALTER TABLE `estoque_peca` DISABLE KEYS */;
INSERT INTO `estoque_peca` VALUES (8,2,1,2),(10,1,2,5);
/*!40000 ALTER TABLE `estoque_peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id_faq` int(11) NOT NULL AUTO_INCREMENT,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `titulo` varchar(40) NOT NULL,
  `descricao` text NOT NULL,
  `tipo_faq_id` int(11) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_faq`),
  KEY `fk_faq_tipo_faq` (`tipo_faq_id`),
  CONSTRAINT `fk_faq_tipo_faq` FOREIGN KEY (`tipo_faq_id`) REFERENCES `tipo_faq` (`id_tipo_faq`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'2019-09-12 23:22:59','Consultar Ordem de Serviço','Para consultar sua ordem de serviço, siga os paços a seguir.<br> 1 - Digite no campo de busca o número informado pelo atendente;<br> 2 - Digite o número do seu cpf.',1,'1143160183.jpg');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornecedor` (
  `id_fornecedor` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `nm_fornecedor` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `num_documento` varchar(14) NOT NULL,
  `ie` varchar(15) DEFAULT NULL,
  `celular` varchar(15) NOT NULL,
  `fone_fixo` varchar(15) DEFAULT NULL,
  `pes_contato` varchar(20) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `numero` varchar(6) DEFAULT NULL,
  `complemento` varchar(40) DEFAULT NULL,
  `bairro` varchar(40) DEFAULT NULL,
  `cidade` varchar(40) NOT NULL,
  `estado` varchar(2) NOT NULL,
  PRIMARY KEY (`id_fornecedor`),
  KEY `fk_fornecedor_usuario` (`usuario_id`),
  CONSTRAINT `fk_fornecedor_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedor`
--

LOCK TABLES `fornecedor` WRITE;
/*!40000 ALTER TABLE `fornecedor` DISABLE KEYS */;
INSERT INTO `fornecedor` VALUES (1,1006,'2019-09-12 23:37:38','MONSTER PARTS','vendas@monsterparts.com','22229234000128','114235141223','19974580100','1932510100','VENDEDOR','01001000','AV. PAULISTA','1000','SALA-240','CENTRO','SAO PAULO','SP'),(2,1006,'2019-09-12 23:37:38','AGIS DISTRIBUICAO','vendas@agis.com','22229234000128','114235141223','19974580100','1932510100','VENDEDOR','01001000','AV. PAULISTA','1000','SALA-240','CENTRO','SAO PAULO','SP');
/*!40000 ALTER TABLE `fornecedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `os`
--

DROP TABLE IF EXISTS `os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `os` (
  `id_os` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_os` timestamp NULL DEFAULT current_timestamp(),
  `data_previsao` date NOT NULL,
  `data_pronto` date DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `tipo` varchar(20) NOT NULL,
  `modelo` varchar(20) NOT NULL,
  `marca` varchar(20) NOT NULL,
  `cor` varchar(20) NOT NULL,
  `serie` varchar(20) NOT NULL,
  `garantia` int(1) NOT NULL DEFAULT 1,
  `info_cliente` varchar(250) NOT NULL,
  `info_tecnico` varchar(250) NOT NULL,
  `info_entrega` varchar(250) NOT NULL,
  `info_interna` varchar(250) NOT NULL,
  `status_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_os`),
  KEY `fk_clientes_as_os` (`cliente_id`),
  KEY `fk_os_as_usuario` (`usuario_id`),
  KEY `fk_os_status` (`status_id`),
  CONSTRAINT `FK_os_os_status` FOREIGN KEY (`status_id`) REFERENCES `os_status` (`id_status`),
  CONSTRAINT `fk_os_as_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `fk_os_as_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `os`
--

LOCK TABLES `os` WRITE;
/*!40000 ALTER TABLE `os` DISABLE KEYS */;
INSERT INTO `os` VALUES (1,1,1006,'2019-09-13 00:53:00','2019-09-13','2019-09-13','2019-09-13','DESKTOP','TX1540','HP','PRETA','H7YFJHUYE5XX',0,'DESLIGOU SOZINHO E NAO LIGA MAIS','MEMORIA QUEIMADA','RETIRADO COM APRESENTACAO DE RG','EQUIPQMENTO TESTEDO POR 6H',5),(2,2,1008,'2019-09-13 00:53:00','2019-09-13','2019-09-13','2019-09-13','MONITOR','T190','SS','PRETA','KIY78EWYY2W',0,'DESLIGOU SOZINHO E NAO LIGA MAIS','FONTE QUEIMADA','','AGUADANDO APROVACAO',2);
/*!40000 ALTER TABLE `os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `os_status`
--

DROP TABLE IF EXISTS `os_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `os_status` (
  `id_status` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `os_status`
--

LOCK TABLES `os_status` WRITE;
/*!40000 ALTER TABLE `os_status` DISABLE KEYS */;
INSERT INTO `os_status` VALUES (1,'ABERTA'),(2,'ORCAMENTO'),(3,'ANDAMENTO'),(4,'FINALIZADA'),(5,'RETIRADA'),(6,'FATURADA');
/*!40000 ALTER TABLE `os_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peca`
--

DROP TABLE IF EXISTS `peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peca` (
  `id_peca` int(11) NOT NULL AUTO_INCREMENT,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `nm_peca` varchar(40) NOT NULL,
  `vl_custo` float(6,2) NOT NULL,
  `vl_venda` float(6,2) NOT NULL,
  PRIMARY KEY (`id_peca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peca`
--

LOCK TABLES `peca` WRITE;
/*!40000 ALTER TABLE `peca` DISABLE KEYS */;
INSERT INTO `peca` VALUES (8,'2019-09-12 23:29:44','HD 80GB MAXTOR DIAMOND MAX 21 STM380215A',249.00,498.00),(9,'2019-09-13 00:27:37','SSD 120GB CRUCIAL BX500',146.00,289.00),(10,'2019-09-13 00:32:23','MEMORIA 8GB DDR4 SANDISK',169.00,245.00);
/*!40000 ALTER TABLE `peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perfil`
--

DROP TABLE IF EXISTS `perfil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfil` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `nivel_perfil` int(1) NOT NULL,
  `nm_perfil` varchar(40) NOT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perfil`
--

LOCK TABLES `perfil` WRITE;
/*!40000 ALTER TABLE `perfil` DISABLE KEYS */;
INSERT INTO `perfil` VALUES (3,4,'ADMINISTRADOR'),(4,3,'MASTER'),(5,2,'SUPER'),(6,1,'USER');
/*!40000 ALTER TABLE `perfil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relaciona_fornecedor_peca`
--

DROP TABLE IF EXISTS `relaciona_fornecedor_peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relaciona_fornecedor_peca` (
  `fornecedor_id` int(11) DEFAULT NULL,
  `peca_id` int(11) DEFAULT NULL,
  KEY `Index 1` (`fornecedor_id`),
  KEY `Index 2` (`peca_id`),
  CONSTRAINT `FK_peca_relaciona_fornecedor` FOREIGN KEY (`peca_id`) REFERENCES `peca` (`id_peca`),
  CONSTRAINT `FK_relaciona_fornecedor_peca` FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedor` (`id_fornecedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relaciona_fornecedor_peca`
--

LOCK TABLES `relaciona_fornecedor_peca` WRITE;
/*!40000 ALTER TABLE `relaciona_fornecedor_peca` DISABLE KEYS */;
INSERT INTO `relaciona_fornecedor_peca` VALUES (1,8),(1,9),(2,9),(2,10),(2,8),(1,10);
/*!40000 ALTER TABLE `relaciona_fornecedor_peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relaciona_os_peca`
--

DROP TABLE IF EXISTS `relaciona_os_peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relaciona_os_peca` (
  `peca_id` int(11) DEFAULT NULL,
  `os_id` int(11) DEFAULT NULL,
  KEY `Index 1` (`peca_id`),
  KEY `Index 2` (`os_id`),
  CONSTRAINT `fk_relaciona_os_peca` FOREIGN KEY (`os_id`) REFERENCES `os` (`id_os`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_relaciona_peca_os` FOREIGN KEY (`peca_id`) REFERENCES `peca` (`id_peca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relaciona_os_peca`
--

LOCK TABLES `relaciona_os_peca` WRITE;
/*!40000 ALTER TABLE `relaciona_os_peca` DISABLE KEYS */;
INSERT INTO `relaciona_os_peca` VALUES (10,1);
/*!40000 ALTER TABLE `relaciona_os_peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relaciona_sku_peca`
--

DROP TABLE IF EXISTS `relaciona_sku_peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relaciona_sku_peca` (
  `peca_id` int(11) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  KEY `Index 1` (`peca_id`),
  KEY `Index 2` (`sku_id`),
  CONSTRAINT `FK_relaciona_sku_peca_peca` FOREIGN KEY (`peca_id`) REFERENCES `peca` (`id_peca`),
  CONSTRAINT `FK_relaciona_sku_peca_sku` FOREIGN KEY (`sku_id`) REFERENCES `sku` (`id_sku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relaciona_sku_peca`
--

LOCK TABLES `relaciona_sku_peca` WRITE;
/*!40000 ALTER TABLE `relaciona_sku_peca` DISABLE KEYS */;
INSERT INTO `relaciona_sku_peca` VALUES (8,1),(9,2);
/*!40000 ALTER TABLE `relaciona_sku_peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sku`
--

DROP TABLE IF EXISTS `sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sku` (
  `id_sku` int(11) NOT NULL AUTO_INCREMENT,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL,
  `sku` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_sku`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sku`
--

LOCK TABLES `sku` WRITE;
/*!40000 ALTER TABLE `sku` DISABLE KEYS */;
INSERT INTO `sku` VALUES (1,'2019-09-12 23:31:11',1,'5RW21JVX'),(2,'2019-09-12 23:31:55',1,'5RW21JVZ'),(3,'2019-09-13 00:42:36',1,'WX41AA8H9LSD');
/*!40000 ALTER TABLE `sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_faq`
--

DROP TABLE IF EXISTS `tipo_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_faq` (
  `id_tipo_faq` int(11) NOT NULL AUTO_INCREMENT,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `descricao` text NOT NULL,
  PRIMARY KEY (`id_tipo_faq`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_faq`
--

LOCK TABLES `tipo_faq` WRITE;
/*!40000 ALTER TABLE `tipo_faq` DISABLE KEYS */;
INSERT INTO `tipo_faq` VALUES (1,'2019-09-12 23:15:03','Consultar O.S'),(2,'2019-09-17 23:33:58','Cadastrar Usuário');
/*!40000 ALTER TABLE `tipo_faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `data_cad` timestamp NULL DEFAULT current_timestamp(),
  `nm_usuario` varchar(60) NOT NULL,
  `cargo` varchar(20) DEFAULT NULL,
  `departamento` varchar(20) NOT NULL,
  `matricula` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `senha` varchar(60) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `perfil_id` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `fk_usuario_perfil` (`perfil_id`),
  CONSTRAINT `fk_usuario_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfil` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=1009 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1006,'2019-09-12 23:09:24','EDILSON BARROS','DEV','TIC',1006,'barros','1234',1,3),(1007,'2019-09-12 23:10:07','CRISTIANO DANTAS','DEV','TIC',1007,'dantas','1234',1,4),(1008,'2019-09-12 23:12:37','VINICIUS LAZARINI','DEV','TIC',1008,'lazarini','1234',1,5);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-04 16:54:51
