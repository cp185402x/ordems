package com.exemple.projetorecicleview.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.exemple.projetorecicleview.R;
import com.exemple.projetorecicleview.model.Produto;

public class ProdutoActivity extends AppCompatActivity {

    private TextView tvNomeProduto;
    private TextView tvPrecoProduto;

    Produto p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);

        this.tvNomeProduto = findViewById(R.id.rv_produtos);
        this.tvPrecoProduto = findViewById(R.id.tv_preco);

        //Verificr se existem parametros passado na intent.
        if(getIntent().getExtras() != null){
            p = (Produto) getIntent().getSerializableExtra("produto");

            this.tvNomeProduto.setText(p.getNome());
            this.tvPrecoProduto.setText("R$" +String.format("%.2f", p.getPreco()));
        }
    }
}