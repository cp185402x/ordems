package com.exemple.projetorecicleview.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.exemple.projetorecicleview.R;
import com.exemple.projetorecicleview.model.Produto;

import java.util.ArrayList;

public class CadastroActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText etNome;
    private EditText etPreco;
    private Button btnAdicionarProduto;

    private ArrayList<Produto> produtos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        this.etNome = findViewById(R.id.et_nome);
        this.etPreco = findViewById(R.id.et_preco);
        this.btnAdicionarProduto = findViewById(R.id.btn_adicionar_produto);

        this.btnAdicionarProduto.setOnClickListener(this);

        if(getIntent().getExtras() != null){
            this.produtos = (ArrayList<Produto>) getIntent().getSerializableExtra("lista de produto");
        }

    }

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btn_adicionar_produto:

                //Toast.makeText(this,"adcionar produto", Toast.LENGTH_SHORT).show();
                this.adicionarProduto();
                break;
        }

    }

    private void adicionarProduto() {
        String nome = this.etNome.getText().toString();
        double preco = Double.parseDouble(this.etPreco.getText().toString());

        if(!nome.equals("") && preco != 0) {
            Produto produto = new Produto(nome, preco);
            this.produtos.add(produto);

            Toast.makeText(this,"Produto cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

            //Criar a intent de retorno que será tratada pelo método onActivityResult da MainActivity
            Intent returnIntent = new Intent(this, MainActivity.class);
            returnIntent.putExtra("lista de produtos atualizada", this.produtos);

            setResult(RESULT_OK, returnIntent);

            finish();
        }
        else {

            Toast.makeText(this, "Preencha os campos corretamente!", Toast.LENGTH_SHORT).show();
        }
    }
}