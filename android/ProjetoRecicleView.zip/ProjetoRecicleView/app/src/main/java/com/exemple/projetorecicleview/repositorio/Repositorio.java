package com.exemple.projetorecicleview.repositorio;

import com.exemple.projetorecicleview.model.Produto;

import java.util.ArrayList;

public class Repositorio {

    public ArrayList<Produto> buscarProdutos(){

        ArrayList<Produto> produtos = new ArrayList<>();

        Produto p1 = new Produto("Alvejante", 4.80);
        Produto p2 = new Produto("Sabão em pó",7.50);
        Produto p3 = new Produto("Esfregão", 5.00);
        Produto p4 = new Produto("Esponja", 1.00);
        Produto p5 = new Produto("Escova", 6.00);
        Produto p6 = new Produto("Amaciante", 6.90);
        Produto p7 = new Produto("Sabão pedra", 2.50);
        Produto p8 = new Produto("Pano de chão", 2.00);
        Produto p9 = new Produto("Bucha", 1.70);
        Produto p10 = new Produto("Aspirador", 999.00);

        produtos.add(p1);
        produtos.add(p2);
        produtos.add(p3);
        produtos.add(p4);
        produtos.add(p5);
        produtos.add(p6);
        produtos.add(p7);
        produtos.add(p8);
        produtos.add(p9);
        produtos.add(p10);

        return produtos;
    }
}
