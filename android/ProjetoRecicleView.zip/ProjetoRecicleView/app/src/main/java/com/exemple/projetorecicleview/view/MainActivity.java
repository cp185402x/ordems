package com.exemple.projetorecicleview.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.exemple.projetorecicleview.R;
import com.exemple.projetorecicleview.adapter.AdapterProdutos;
import com.exemple.projetorecicleview.model.Produto;
import com.exemple.projetorecicleview.repositorio.Repositorio;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView rv_produtos;
    private Button btn_adicionar_produto;

    private ArrayList<Produto> produtos;
    private AdapterProdutos adapterProdutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.btn_adicionar_produto = findViewById(R.id.btn_adicionar_produto);
        this.btn_adicionar_produto.setOnClickListener(this);

        this.rv_produtos = findViewById(R.id.rv_produtos);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        this.rv_produtos.setLayoutManager(linearLayoutManager);

        Repositorio repositorio = new Repositorio();

        this.produtos = new ArrayList<>();
        this.produtos = repositorio.buscarProdutos();

        this.adapterProdutos = new AdapterProdutos(this, this.produtos);
        this.rv_produtos.setAdapter(this.adapterProdutos);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_adicionar_produto:
                //Toast.makeText(this, "Clicou no botão cadastrar", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, CadastroActivity.class);
                intent.putExtra("lista de produto", this.produtos);

                startActivityForResult(intent, 1);
                break;
        }

    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 1:

                if(resultCode == RESULT_OK){
                    //Recuperar o produto que foi cadastrado
                    this.produtos = (ArrayList<Produto>) data.getSerializableExtra("lista de produtos atualizada");
                    //Chama o método que notifica o adapter
                    this.adapterProdutos.atualizarAdapter(this.produtos);
                }
                break;
        }

    }
}

